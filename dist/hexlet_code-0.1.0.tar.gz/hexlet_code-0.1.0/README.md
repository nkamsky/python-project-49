### Hexlet tests and linter status:
[![Actions Status](https://github.com/nkamsky/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/nkamsky/python-project-49/actions)

<a href="https://codeclimate.com/github/nkamsky/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/a158ba0777ef1ee61aef/maintainability" /></a>

https://asciinema.org/a/1efdBxFetNYq1lhOe790sJXUj

https://asciinema.org/a/Vkw4Le49ltNROoj2m1WiU5PGt
